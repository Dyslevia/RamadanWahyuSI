<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\BahanController;
use App\Http\Controllers\GudangController;
use App\Http\Controllers\OutletController;
use App\Http\Controllers\PegawaiController;
use App\Http\Controllers\PeralatanController;
use App\Http\Controllers\ProduksiController;
use App\Http\Controllers\StokBahanController;
use App\Http\Controllers\StokBarangController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('/login/welcome');
});
Route::get('/register', function () {
    return view('/login/register');
});
Route::get('/home', function () {
    return view('/admin/home');
});
Route::get('/barang', function () {
    return view('admin/barang');
});
Route::get('/bahan', function () {
    return view('/admin/bahan');
})->name('bahan');

Route::get('/gudangbahan', function () {
    return view('admin.gudangbahan');
})->name('gudangbahan');

Route::get('/gudangstok', function () {
    return view('admin.gudangstok');
})->name('gudangstok');

Route::get('/produksi', function () {
    return view('admin.produksi');
})->name('produksi');

Route::get('/pegawai', function () {
    return view('admin.pegawai');
})->name('pegawai');

Route::get('/peralatan', function () {
    return view('admin.peralatan');
})->name('peralatan');

Route::get('/outlet', function () {
    return view('admin.outlet');
})->name('outlet');

Route::get('/transaksi', function () {
    return view('admin.transaksi');
})->name('transaksi');

// Barang
Route::get('/barang', [BarangController::class, 'index'])->name('barang.index');
Route::get('/barang/add', [BarangController::class, 'addView'])->name('barang.create');
Route::post('/barang', [BarangController::class, 'store']);
Route::get('/barang/edit/{id}', [BarangController::class, 'edit'])->name('barang.edit');
Route::put('/barang/update/{id}', [BarangController::class, 'update'])->name('barang.update');
Route::get('/barang/delete/{id}', [BarangController::class, 'destroy']);

//Bahan
Route::get('/bahan', [BahanController::class, 'index'])->name('bahan.index');
Route::get('/bahan/add', [BahanController::class, 'addView'])->name('bahan.create');
Route::post('/bahan', [BahanController::class, 'store']);
Route::get('/bahan/edit/{id}', [BahanController::class, 'edit'])->name('bahan.edit');
Route::put('/bahan/update/{id}', [BahanController::class, 'update'])->name('bahan.update');
Route::get('/bahan/delete/{id}', [BahanController::class, 'destroy']);

//Gudang
Route::get('/gudang', [GudangController::class, 'index'])->name('gudang.index');
Route::get('/gudang/add', [GudangController::class, 'addView'])->name('gudang.create');
Route::post('/gudang', [GudangController::class, 'store']);
Route::get('/gudang/edit/{id}', [GudangController::class, 'edit'])->name('gudang.edit');
Route::put('/gudang/update/{id}', [GudangController::class, 'update'])->name('gudang.update');
Route::get('/gudang/delete/{id}', [GudangController::class, 'destroy']);

//Outlet
Route::get('/outlet', [OutletController::class, 'index'])->name('outlet.index');
Route::get('/outlet/add', [OutletController::class, 'addView'])->name('outlet.create');
Route::post('/outlet', [OutletController::class, 'store']);
Route::get('/outlet/edit/{id}', [OutletController::class, 'edit'])->name('outlet.edit');
Route::put('/outlet/update/{id}', [OutletController::class, 'update'])->name('outlet.update');
Route::get('/outlet/delete/{id}', [OutletController::class, 'destroy']);

//Pegawai
Route::get('/pegawai', [PegawaiController::class, 'index'])->name('pegawai.index');
Route::get('/pegawai/add', [PegawaiController::class, 'addView'])->name('pegawai.create');
Route::post('/pegawai', [PegawaiController::class, 'store']);
Route::get('/pegawai/edit/{id}', [PegawaiController::class, 'edit'])->name('pegawai.edit');
Route::put('/pegawai/update/{id}', [PegawaiController::class, 'update'])->name('pegawai.update');
Route::get('/pegawai/delete/{id}', [PegawaiController::class, 'destroy']);

//Peralatan
Route::get('/peralatan', [PeralatanController::class, 'index'])->name('peralatan.index');
Route::get('/peralatan/add', [PeralatanController::class, 'addView'])->name('peralatan.create');
Route::post('/peralatan', [PeralatanController::class, 'store']);
Route::get('/peralatan/edit/{id}', [PeralatanController::class, 'edit'])->name('peralatan.edit');
Route::put('/peralatan/update/{id}', [PeralatanController::class, 'update'])->name('peralatan.update');
Route::get('/peralatan/delete/{id}', [PeralatanController::class, 'destroy']);

//Produksi
Route::get('/produksi', [ProduksiController::class, 'index'])->name('produksi.index');
Route::get('/produksi/add', [ProduksiController::class, 'addView'])->name('produksi.create');
Route::post('/produksi', [ProduksiController::class, 'store']);
Route::get('/produksi/edit/{id}', [ProduksiController::class, 'edit'])->name('produksi.edit');
Route::put('/produksi/update/{id}', [ProduksiController::class, 'update'])->name('produksi.update');
Route::get('/produksi/delete/{id}', [ProduksiController::class, 'destroy']);

//Stok Bahan
Route::get('/stok-bahan', [StokBahanController::class, 'index'])->name('stok-bahan.index');
Route::get('/stok-bahan/add', [StokBahanController::class, 'addView'])->name('stok-bahan.create');
Route::post('/stok-bahan', [StokBahanController::class, 'store']);
Route::get('/stok-bahan/edit/{id}', [StokBahanController::class, 'edit'])->name('stok-bahan.edit');
Route::put('/stok-bahan/update/{id}', [StokBahanController::class, 'update'])->name('stok-bahan.update');
Route::get('/stok-bahan/delete/{id}', [StokBahanController::class, 'destroy']);

//Stok Barang
Route::get('/stok-barang', [StokBarangController::class, 'index'])->name('stok-barang.index');
Route::get('/stok-barang/add', [StokBarangController::class, 'addView'])->name('stok-barang.create');
Route::post('/stok-barang', [StokBarangController::class, 'store']);
Route::get('/stok-barang/edit/{id}', [StokBarangController::class, 'edit'])->name('stok-barang.edit');
Route::put('/stok-barang/update/{id}', [StokBarangController::class, 'update'])->name('stok-barang.update');
Route::get('/stok-barang/delete/{id}', [StokBarangController::class, 'destroy']);