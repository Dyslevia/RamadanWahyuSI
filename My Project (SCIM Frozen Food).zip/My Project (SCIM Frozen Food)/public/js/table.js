$(function() {
    $(document).ready(function() {
      $('#example').DataTable();
    });
  });