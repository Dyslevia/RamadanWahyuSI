<?php

namespace App\Http\Controllers;
use App\Models\Barang;
use Carbon\Carbon;

use Illuminate\Http\Request;

class BarangController extends Controller
{
    public function index()
    {
        $barang = Barang::all();

        return view('barang.index', [
            'barang' => $barang,
        ]);
    }
    public function addView()
    {
        return view('barang.create');
    }

    public function store(Request $request)
    {
        $data = [
            'nama_barang' => $request->input('nama_barang'),
            'kategori' => $request->input('kategori'),
            'updated_at' => Carbon::now(),
            'created_at' => Carbon::now(),
        ];

        Barang::create($data);

        return redirect('/barang');
    }
    public function edit($id)
    {
        $barang = Barang::findOrFail($id);
        return view('barang.edit', compact('barang', ));
    }

    public function update(Request $request, $id)
    {
        $barang = Barang::findOrFail($id);
        $barang->nama_barang = $request->nama_barang;
        $barang->kategori = $request->kategori;
        $barang->save();

        return redirect('/barang');
    }

    public function destroy($id)
    {
        $barang = Barang::findOrFail($id);
        $barang->delete();
        return redirect('/barang');
    }
}

