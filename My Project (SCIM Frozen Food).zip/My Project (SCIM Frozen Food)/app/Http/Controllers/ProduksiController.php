<?php

namespace App\Http\Controllers;
use App\Models\Produksi;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ProduksiController extends Controller
{
    public function index()
    {
        $produksi = Produksi::all();

        return view('produksi.index', [
            'produksi' => $produksi,
        ]);
    }
    public function addView()
    {
        return view('produksi.create');
    }

    public function store(Request $request)
    {
        $data = [
            'jumlah_produksi' => $request->input('jumlah_produksi'),
            'biaya_produksi' => $request->input('biaya_produksi'),
            'tanggal_produksi' => $request->input('tanggal_produksi'),
            'updated_at' => Carbon::now(),
            'created_at' => Carbon::now(),
        ];

        Produksi::create($data);

        return redirect('/produksi');
    }
    public function edit($id)
    {
        $produksi = Produksi::findOrFail($id);
        return view('produksi.edit', compact('produksi', ));
    }

    public function update(Request $request, $id)
    {
        $produksi = Produksi::findOrFail($id);
        $produksi->jumlah_produksi= $request->jumlah_produksi;
        $produksi->biaya_produksi= $request->biaya_produksi;
        $produksi->tanggal_produksi= $request->tanggal_produksi;
        $produksi->save();

        return redirect('/produksi');
    }

    public function destroy($id)
    {
        $produksi = Produksi::findOrFail($id);
        $produksi->delete();
        return redirect('/produksi');
    }
}
