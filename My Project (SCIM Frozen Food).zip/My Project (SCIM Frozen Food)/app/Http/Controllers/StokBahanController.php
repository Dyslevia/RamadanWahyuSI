<?php

namespace App\Http\Controllers;
use App\Models\StokBahan;
use Carbon\Carbon;
use Illuminate\Http\Request;

class StokBahanController extends Controller
{
    public function index()
    {
        $stok_bahan = StokBahan::all();

        return view('stok_bahan.index', [
            'stok_bahan' => $stok_bahan,
        ]);
    }
    public function addView()
    {
        return view('stok_bahan.create');
    }

    public function store(Request $request)
    {
        $data = [
            'jumlah_stok' => $request->input('jumlah_stok'),
            'updated_at' => Carbon::now(),
            'created_at' => Carbon::now(),
        ];

        StokBahan::create($data);

        return redirect('/stok-bahan');
    }
    public function edit($id)
    {
        $stok_bahan = StokBahan::findOrFail($id);
        return view('stok_bahan.edit', compact('stok_bahan', ));
    }

    public function update(Request $request, $id)
    {
        $stok_bahan = StokBahan::findOrFail($id);
        $stok_bahan->jumlah_stok= $request->jumlah_stok;
        $stok_bahan->save();

        return redirect('/stok-bahan');
    }

    public function destroy($id)
    {
        $stok_bahan = StokBahan::findOrFail($id);
        $stok_bahan->delete();
        return redirect('/stok-bahan');
    }
}
