<?php

namespace App\Http\Controllers;
use App\Models\StokBarang;
use Carbon\Carbon;
use Illuminate\Http\Request;

class StokBarangController extends Controller
{
    public function index()
    {
        $stok_barang = StokBarang::all();

        return view('stok_barang.index', [
            'stok_barang' => $stok_barang,
        ]);
    }
    public function addView()
    {
        return view('stok_barang.create');
    }

    public function store(Request $request)
    {
        $data = [
            'jumlah_stok' => $request->input('jumlah_stok'),
            'updated_at' => Carbon::now(),
            'created_at' => Carbon::now(),
        ];

        StokBarang::create($data);

        return redirect('/stok-barang');
    }
    public function edit($id)
    {
        $stok_barang = StokBarang::findOrFail($id);
        return view('stok_barang.edit', compact('stok_barang', ));
    }

    public function update(Request $request, $id)
    {
        $stok_barang = StokBarang::findOrFail($id);
        $stok_barang->jumlah_stok= $request->jumlah_stok;
        $stok_barang->save();

        return redirect('/stok-barang');
    }

    public function destroy($id)
    {
        $stok_barang = StokBarang::findOrFail($id);
        $stok_barang->delete();
        return redirect('/stok-barang');
    }
}
