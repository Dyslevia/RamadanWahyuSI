<?php

namespace App\Http\Controllers;
use App\Models\Bahan;
use Carbon\Carbon;

use Illuminate\Http\Request;

class BahanController extends Controller
{
    public function index()
    {
        $bahan = Bahan::all();

        return view('bahan.index', [
            'bahan' => $bahan,
        ]);
    }
    public function addView()
    {
        return view('bahan.create');
    }

    public function store(Request $request)
    {
        $data = [
            'nama_bahan' => $request->input('nama_bahan'),
            'deskripsi' => $request->input('deskripsi'),
            'updated_at' => Carbon::now(),
            'created_at' => Carbon::now(),
        ];

        Bahan::create($data);

        return redirect('/bahan');
    }
    public function edit($id)
    {
        $bahan = Bahan::findOrFail($id);
        return view('bahan.edit', compact('bahan', ));
    }

    public function update(Request $request, $id)
    {
        $bahan = Bahan::findOrFail($id);
        $bahan->nama_bahan = $request->nama_bahan;
        $bahan->deskripsi = $request->deskripsi;
        $bahan->save();

        return redirect('/bahan');
    }

    public function destroy($id)
    {
        $bahan= Bahan::findOrFail($id);
        $bahan->delete();
        return redirect('/bahan');
    }
}
