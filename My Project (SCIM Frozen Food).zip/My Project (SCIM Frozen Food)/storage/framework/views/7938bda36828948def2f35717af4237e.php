

<?php $__env->startSection('content'); ?>

        <h4>Edit Produksi</h4>
        <form action="/produksi/update/<?php echo e($produksi->id); ?>" method="POST" class="">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="jumlah_produksi" class="form-label">Jumlah Produksi</label>
                <input type="text" class="form-control" id="jumlah_produksi" name="jumlah_produksi" placeholder="Masukkan Jumlah Produksi" value="<?php echo e($produksi->jumlah_produksi); ?>">
            </div>
            <br>
            <div class="form-group">
                <label for="biaya_produksi" class="form-label">Biaya Produksi</label>
                <input type="text" class="form-control" id="biaya_produksi" name="biaya_produksi" placeholder="Masukkan Biaya Produksi" value="<?php echo e($produksi->biaya_produksi); ?>">
            </div>
            <br>
            <div class="form-group">
                <label for="tanggal_produksi" class="form-label">Tanggal Produksi</label>
                <input type="text" class="form-control" id="tanggal_produksi" name="tanggal_produksi" placeholder="Masukkan Tanggal Produksi" value="<?php echo e($produksi->tanggal_produksi); ?>">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/produksi/edit.blade.php ENDPATH**/ ?>