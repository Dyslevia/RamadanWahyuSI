

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('pegawai.create')); ?>" class="btn btn-primary">Tambahkan Data Jabatan</a>
    <br><br>

    <table class="table table-bordered table-striped" id="example1">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Nama Pegawai</th>
          <th scope="col">Jabatan</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
        <tbody>
          <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($item->id); ?></th>
              <td><?php echo e($item->nama_pegawai); ?></td>
              <td><?php echo e($item->jabatan); ?></td>
              <td>
                <a class="btn btn-warning btn-sm" href="/pegawai/edit/<?php echo e($item->id); ?>">Edit</a>
                <a class="btn btn-danger btn-sm" href="/pegawai/delete/<?php echo e($item->id); ?>" onclick="return confirm('Are You Sure')">Delete</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/pegawai/index.blade.php ENDPATH**/ ?>