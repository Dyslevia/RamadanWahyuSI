

<?php $__env->startSection('content'); ?>

        <h4>Edit Peralatan</h4>
        <form action="/peralatan/update/<?php echo e($peralatan->id); ?>" method="POST" class="">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="nama_alat" class="form-label">Nama Alat</label>
                <input type="text" class="form-control" id="nama_alat" name="nama_alat" placeholder="Masukkan Nama Alat" value="<?php echo e($peralatan->nama_alat); ?>">
            </div>
            <div class="form-group">
                <label for="jumlah" class="form-label">jumlah</label>
                <input type="text" class="form-control" id="jumlah" name="jumlah" placeholder="Masukkan Jumlah" value="<?php echo e($peralatan->jumlah); ?>">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/peralatan/edit.blade.php ENDPATH**/ ?>