

<?php $__env->startSection('content'); ?>

        <h4>Edit Stok Barang</h4>
        <form action="/stok-barang/update/<?php echo e($stok_barang->id); ?>" method="POST" class="">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="jumlah_stok" class="form-label">Jumlah stok</label>
                <input type="text" class="form-control" id="jumlah_stok" name="jumlah_stok" placeholder="Masukkan Jumlah Stok" value="<?php echo e($stok_barang->jumlah_stok); ?>">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/stok_barang/edit.blade.php ENDPATH**/ ?>