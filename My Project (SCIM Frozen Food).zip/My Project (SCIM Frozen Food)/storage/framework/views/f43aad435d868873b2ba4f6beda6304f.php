

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('bahan.create')); ?>" class="btn btn-primary">Tambahkan Bahan</a>
    <br><br>

    <table class="table table-bordered table-striped" id="example1">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Nama Bahan</th>
          <th scope="col">Deskripsi</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
        <tbody>
          <?php $__currentLoopData = $bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($item->id); ?></th>
              <td><?php echo e($item->nama_bahan); ?></td>
              <td><?php echo e($item->deskripsi); ?></td>
              <td>
                <a class="btn btn-warning btn-sm" href="/bahan/edit/<?php echo e($item->id); ?>">Edit</a>
                <a class="btn btn-danger btn-sm" href="/bahan/delete/<?php echo e($item->id); ?>" onclick="return confirm('Are You Sure')">Delete</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/bahan/index.blade.php ENDPATH**/ ?>