
<?php $__env->startSection('content'); ?>

        <form action="/stok-barang" method="POST" class="">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="jumlah_stok" class="form-label">Jumlah Stok</label>
                <input type="text" class="form-control" id="jumlah_stok" name="jumlah_stok" placeholder="Masukkan Jumlah Stok Barang">
            </div>
            <button class="btn btn-primary btn-block" type="submit">Simpan</button>
            <a href="<?php echo e(route('stok-barang.index')); ?>" class="btn btn-secondary btn-block">Batal</a>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/stok_barang/create.blade.php ENDPATH**/ ?>