

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('stok-bahan.create')); ?>" class="btn btn-primary">Tambahkan Data Stok Bahan</a>
    <br><br>
<div class="tabel-responsive">
  <div id="stok-tabel" class="tabel">
    <table class="table table-bordered table-striped" id="example1">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Jumlah Stok</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
        <tbody>
          <?php $__currentLoopData = $stok_bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($item->id); ?></th>
              <td><?php echo e($item->jumlah_stok); ?></td>
              <td>
                <a class="btn btn-warning btn-sm" href="/stok-bahan/edit/<?php echo e($item->id); ?>">Edit</a>
                <a class="btn btn-danger btn-sm" href="/stok-bahan/delete/<?php echo e($item->id); ?>" onclick="return confirm('Are You Sure')">Delete</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/stok_bahan/index.blade.php ENDPATH**/ ?>