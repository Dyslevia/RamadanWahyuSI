

<?php $__env->startSection('content'); ?>
<h1 class="display-6">Data Gudang Stok</h1>
<div class="d-flex justify-content-between align-items-center">
  <button data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-primary mt-3"><i class="bi bi-calendar2-plus"></i> Tambah</button>

  <div class="dropdown">
    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
      Dropdown button
    </button>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Action</a></li>
      <li><a class="dropdown-item" href="#">Another action</a></li>
      <li><a class="dropdown-item" href="#">Something else here</a></li>
    </ul>
  </div>
</div>

<div class="table-responsive">
  <table id="example" style="width:100%" class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>Kode Gudang Barang</th>
        <th>Kode Barang</th>
        <th>Kode Produksi</th>
        <th>Jumlah</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>GA0001</td>
        <td>DA0001 </td>
        <td>SP0001</td>
        <td>50</td>
      </tr>
      <tr>
        <td>GA0002</td>
        <td>DA0002</td>
        <td>SP0002</td>
        <td>100</td>
      </tr>
      <tr>
        <td>GA0003</td>
        <td>DA0003</td>
        <td>SP0003</td>
        <td>200</td>
      </tr>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/admin/gudangstok.blade.php ENDPATH**/ ?>