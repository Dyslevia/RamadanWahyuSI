
<?php $__env->startSection('content'); ?>

        <form action="/peralatan" method="POST" class="">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="nama_alat" class="form-label">Nama Alat</label>
                <input type="text" class="form-control" id="nama_alat" name="nama_alat" placeholder="Masukkan Nama Alamat">
            </div>
            <div class="mb-3">
                <label for="jumlah" class="form-label">Jumlah</label>
                <input type="text" class="form-control" id="jumlah" name="jumlah" placeholder="Masukkan Jumlah">
            </div>
            <button class="btn btn-primary btn-block" type="submit">Simpan</button>
            <a href="<?php echo e(route('peralatan.index')); ?>" class="btn btn-secondary btn-block">Batal</a>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/peralatan/create.blade.php ENDPATH**/ ?>