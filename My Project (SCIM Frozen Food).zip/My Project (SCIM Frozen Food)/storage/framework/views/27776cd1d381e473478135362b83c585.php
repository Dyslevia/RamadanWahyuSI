
<?php $__env->startSection('content'); ?>

        <form action="/barang" method="POST" class="">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="nama_barang" class="form-label">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" placeholder="Masukan Nama Barang">
            </div>
            <div class="mb-3">
                <label for="kategori" class="form-label">Kategori</label>
                <input type="text" class="form-control" id="kategori" name="kategori" placeholder="Masukan Nama Kategori">
            </div>
            <button class="btn btn-primary btn-block" type="submit">Simpan</button>
            <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-secondary btn-block">Batal</a>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/barang/create.blade.php ENDPATH**/ ?>