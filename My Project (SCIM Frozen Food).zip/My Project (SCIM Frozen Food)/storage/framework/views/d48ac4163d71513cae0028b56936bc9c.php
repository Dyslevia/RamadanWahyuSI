

<?php $__env->startSection('content'); ?>
<h1 class="display-6">Data Barang</h1>
<div class="table-responsive">
            <table id="example" style="width:100%" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Kode Barang</th>
                  <th>Nama Barang</th>
                  <th>Kategori</th>
                  <th>kode bahan</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>N00001</td>
                  <td>Nugget </td>
                  <td>Nugget Forzen</td>
                  <td>A001</td>
                </tr>
                <tr>
                  <td>DM0001</td>
                  <td>Siomay</td>
                  <td>Siomay Frozen</td>
                  <td>A002</td>
                </tr>
                <tr>
                  <td>BA0001</td>
                  <td>Bakso</td>
                  <td>Bakso Frozen</td>
                  <td>BA00011</td>
                </tr>
              </tbody>
            </table>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/admin/barang.blade.php ENDPATH**/ ?>