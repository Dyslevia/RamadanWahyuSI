

<?php $__env->startSection('content'); ?>
<h1 class="display-6">Data Barang</h1>
<div class="table-responsive">
            <table id="example" style="width:100%" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Kode Barang</th>
                  <th>Nama Barang</th>
                  <th>Kategori</th>
                  <th>kode bahan</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>RF0001</td>
                  <td>Original Flavour</td>
                  <td>Rokok Filter</td>
                  <td>BB0001</td>
                </tr>
                <tr>
                  <td>RF0002</td>
                  <td>Orange Flavour</td>
                  <td>Rokok Filter varian jeruk</td>
                  <td>BB0002</td>
                </tr>
                <tr>
                  <td>Ashton Cox</td>
                  <td>Junior Technical Author</td>
                  <td>San Francisco</td>
                  <td>66</td>
                </tr>
              </tbody>
            </table>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/admin/barang.blade.php ENDPATH**/ ?>