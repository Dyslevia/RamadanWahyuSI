
<?php $__env->startSection('content'); ?>

        <form action="/produksi" method="POST" class="">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="jumlah_produksi" class="form-label">Jumlah Produksi</label>
                <input type="text" class="form-control" id="jumlah_produksi" name="jumlah_produksi" placeholder="Masukkan Jumlah Produksi">
            </div>
            <div class="mb-3">
                <label for="biaya_produksi" class="form-label">Biaya Produksi</label>
                <input type="text" class="form-control" id="biaya_produksi" name="biaya_produksi" placeholder="Masukkan Biaya Produksi">
            </div>
            <div class="mb-3">
                <label for="tanggal_produksi" class="form-label">Tanggal Produksi</label>
                <input type="text" class="form-control" id="tanggal_produksi" name="tanggal_produksi" placeholder="Masukkan Tanggal Produksi">
            </div>
            <button class="btn btn-primary btn-block" type="submit">Simpan</button>
            <a href="<?php echo e(route('produksi.index')); ?>" class="btn btn-secondary btn-block">Batal</a>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/produksi/create.blade.php ENDPATH**/ ?>