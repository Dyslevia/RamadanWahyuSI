<?php $__env->startSection('content'); ?>
<h1 class="display-6">Data User</h1>
<div class="d-flex justify-content-between align-items-center">
  <button class="btn btn-primary mt-3"><i class="bi bi-calendar2-plus"></i> Tambah</button>

  <div class="dropdown">
    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
      Dropdown button
    </button>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Action</a></li>
      <li><a class="dropdown-item" href="#">Another action</a></li>
      <li><a class="dropdown-item" href="#">Something else here</a></li>
    </ul>
  </div>
</div>

<table class="table mt-4">
    <tr style="background-color: black; color: white">
        <th>Nama User</th>
        <th>No. Telp</th>
        <th></th>
    </tr>
    <tr>
        <td>Tes</td>
        <td>123</td>
        <td>
          <a href="">Edit</a>
          <a href="">Hapus</a>
        </td>
    </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Sistem Informasi\example-app\resources\views/welcome.blade.php ENDPATH**/ ?>