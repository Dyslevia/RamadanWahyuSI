

<?php $__env->startSection('content'); ?>

        <h4>Edit Barang</h4>
        <form action="/barang/update/<?php echo e($barang->id); ?>" method="POST" class="">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="nama_barang" class="form-label">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" placeholder="Masukkan Nama Barang" value="<?php echo e($barang->nama_barang); ?>">
            </div>
            <div class="form-group">
                <label for="kategori" class="form-label">Kategori</label>
                <input type="text" class="form-control" id="kategori" name="kategori" placeholder="Masukkan Nama Kategori" value="<?php echo e($barang->kategori); ?>">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/barang/edit.blade.php ENDPATH**/ ?>