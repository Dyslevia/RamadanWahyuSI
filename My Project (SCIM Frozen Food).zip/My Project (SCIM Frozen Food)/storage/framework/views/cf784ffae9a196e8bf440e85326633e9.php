

<?php $__env->startSection('content'); ?>

        <h4>Edit Bahan</h4>
        <form action="/bahan/update/<?php echo e($bahan->id); ?>" method="POST" class="">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="nama_bahan" class="form-label">Nama bahan</label>
                <input type="text" class="form-control" id="nama_bahan" name="nama_bahan" placeholder="Masukkan Nama Bahan" value="<?php echo e($bahan->nama_bahan); ?>">
            </div>
            <div class="form-group">
                <label for="deskripsi" class="form-label">Deskripsi</label>
                <input type="text" class="form-control" id="deskripsi" name="deskripsi" placeholder="Masukkan Deskripsi" value="<?php echo e($bahan->deskripsi); ?>">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views/bahan/edit.blade.php ENDPATH**/ ?>