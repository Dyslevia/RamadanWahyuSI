<?php $__env->startSection('content'); ?>
<h1 class="display-6">Selamat Datang Admin</h1>
<div class="d-flex justify-content-between align-items-center">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My Project\resources\views//admin/home.blade.php ENDPATH**/ ?>