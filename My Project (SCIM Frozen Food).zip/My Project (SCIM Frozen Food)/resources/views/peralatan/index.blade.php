@extends('layouts.dashboard')

@section('content')

    <a href="{{ route('peralatan.create') }}" class="btn btn-primary">Tambahkan Data Peralatan</a>
    <br><br>

    <table class="table table-bordered table-striped" id="example1">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Nama Alat</th>
          <th scope="col">Jumlah</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
        <tbody>
          @foreach ($peralatan as $item)
            <tr>
              <th scope="row">{{ $item->id }}</th>
              <td>{{ $item->nama_alat }}</td>
              <td>{{ $item->jumlah}}</td>
              <td>
                <a class="btn btn-warning btn-sm" href="/peralatan/edit/{{$item->id}}">Edit</a>
                <a class="btn btn-danger btn-sm" href="/peralatan/delete/{{$item->id}}" onclick="return confirm('Are You Sure')">Delete</a>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
@endsection