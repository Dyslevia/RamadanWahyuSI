@extends('layouts.dashboard')

@section('content')

        <h4>Edit Peralatan</h4>
        <form action="/peralatan/update/{{$peralatan->id}}" method="POST" class="">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nama_alat" class="form-label">Nama Alat</label>
                <input type="text" class="form-control" id="nama_alat" name="nama_alat" placeholder="Masukkan Nama Alat" value="{{$peralatan->nama_alat}}">
            </div>
            <div class="form-group">
                <label for="jumlah" class="form-label">jumlah</label>
                <input type="text" class="form-control" id="jumlah" name="jumlah" placeholder="Masukkan Jumlah" value="{{$peralatan->jumlah}}">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

@endsection