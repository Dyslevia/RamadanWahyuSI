@extends('layouts.dashboard')

@section('content')

        <h4>Edit Produksi</h4>
        <form action="/produksi/update/{{$produksi->id}}" method="POST" class="">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="jumlah_produksi" class="form-label">Jumlah Produksi</label>
                <input type="text" class="form-control" id="jumlah_produksi" name="jumlah_produksi" placeholder="Masukkan Jumlah Produksi" value="{{$produksi->jumlah_produksi}}">
            </div>
            <br>
            <div class="form-group">
                <label for="biaya_produksi" class="form-label">Biaya Produksi</label>
                <input type="text" class="form-control" id="biaya_produksi" name="biaya_produksi" placeholder="Masukkan Biaya Produksi" value="{{$produksi->biaya_produksi}}">
            </div>
            <br>
            <div class="form-group">
                <label for="tanggal_produksi" class="form-label">Tanggal Produksi</label>
                <input type="text" class="form-control" id="tanggal_produksi" name="tanggal_produksi" placeholder="Masukkan Tanggal Produksi" value="{{$produksi->tanggal_produksi}}">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

@endsection