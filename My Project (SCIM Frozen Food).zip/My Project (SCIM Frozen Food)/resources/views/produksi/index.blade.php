@extends('layouts.dashboard')

@section('content')

    <a href="{{ route('produksi.create') }}" class="btn btn-primary">Tambahkan Data Produksi</a>
    <br><br>

    <table class="table table-bordered table-striped" id="example1">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Jumlah Produksi</th>
          <th scope="col">Biaya Produksi</th>
          <th scope="col">Tanggal Produksi</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
        <tbody>
          @foreach ($produksi as $item)
            <tr>
              <th scope="row">{{ $item->id }}</th>
              <td>{{ $item->jumlah_produksi }}</td>
              <td>{{ $item->biaya_produksi }}</td>
              <td>{{ $item->tanggal_produksi }}</td>
              <td>
                <a class="btn btn-warning btn-sm" href="/produksi/edit/{{$item->id}}">Edit</a>
                <a class="btn btn-danger btn-sm" href="/produksi/delete/{{$item->id}}" onclick="return confirm('Are You Sure')">Delete</a>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
@endsection