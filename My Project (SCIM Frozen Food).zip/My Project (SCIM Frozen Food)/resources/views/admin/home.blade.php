@extends('layouts.dashboard')

@section('content')
<h1 class="display-6">Selamat Datang Admin</h1>
<div class="d-flex justify-content-between align-items-center">

@endsection