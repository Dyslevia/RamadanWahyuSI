@extends('layouts.dashboard')

@section('content')
<h1 class="display-6">Data Gudang Bahan</h1>

<form>
    <div class="mb-3 mt-4">
      <label for="exampleInputEmail1" class="form-label">Nama Bahan</label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    </div>
    <div class="mb-3 mt-4">
        <label for="exampleInputEmail1" class="form-label">Type Bahan</label>
        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
      </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Tanggal Produksi Bahan</label>
      <input type="text" class="form-control" id="exampleInputPassword1">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
@endsection