@extends('layouts.dashboard')

@section('content')
<h1 class="display-6">Data Transaksi</h1>
<div class="d-flex justify-content-between align-items-center">
  <button data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-primary mt-3"><i class="bi bi-calendar2-plus"></i> Tambah</button>

  <div class="dropdown">
    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
      Dropdown button
    </button>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Action</a></li>
      <li><a class="dropdown-item" href="#">Another action</a></li>
      <li><a class="dropdown-item" href="#">Something else here</a></li>
    </ul>
  </div>
</div>

<div class="table-responsive">
  <table id="example" style="width:100%" class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>ID Transaksi</th>
        <th>Kode Outlet</th>
        <th>Kode Bayar</th>
        <th>Total</th>
        <th>Metode Bayar</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>T0001</td>
        <td>TO0001</td>
        <td>BYR0001</td>
        <td>1.500.000 Rp</td>
        <td>Cash</td>
      </tr>
      <tr>
        <td>T0002</td>
        <td>TO0002</td>
        <td>BYR0002</td>
        <td>500.000 Rp</td>
        <td>Cash</td>
      </tr>
      <tr>
        <td>T0003</td>
        <td>TO0003</td>
        <td>BYR0003</td>
        <td>1.000.000 Rp</td>
        <td>Transfer</td>
      </tr>
    </tbody>
  </table>
</div>

<div class="row row-cols-1 mt-4 row-cols-md-4 g-4">
    <div class="col">
      <div class="card">
        <img src="https://media.sproutsocial.com/uploads/2017/02/10x-featured-social-media-image-size.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="https://media.sproutsocial.com/uploads/2017/02/10x-featured-social-media-image-size.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="https://media.sproutsocial.com/uploads/2017/02/10x-featured-social-media-image-size.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="https://media.sproutsocial.com/uploads/2017/02/10x-featured-social-media-image-size.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        </div>
      </div>
    </div>
  </div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Jenis Jerawat</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form method="POST" id="form_upload">
                @csrf
                <input type="hidden" name="id">
                <div class="row">
                    <div class="col-12">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" name="nama">
                            <small id="error_nama" class="text-danger"></small>
                          </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">No.Telepon</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" name="no_telp">
                            <small id="error_no_telp" class="text-danger"></small>
                          </div>
                    </div>
                </div>
        
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
        </div>
      </div>
    </div>
  </div>
@endsection