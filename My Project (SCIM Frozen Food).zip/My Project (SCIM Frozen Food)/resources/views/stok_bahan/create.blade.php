@extends('layouts.dashboard')
@section('content')

        <form action="/stok-bahan" method="POST" class="">
            @csrf
            <div class="mb-3">
                <label for="jumlah_stok" class="form-label">Jumlah Stok</label>
                <input type="text" class="form-control" id="jumlah_stok" name="jumlah_stok" placeholder="Masukkan Jumlah Stok Bahan">
            </div>
            <button class="btn btn-primary btn-block" type="submit">Simpan</button>
            <a href="{{ route('stok-bahan.index') }}" class="btn btn-secondary btn-block">Batal</a>
        </form>

@endsection