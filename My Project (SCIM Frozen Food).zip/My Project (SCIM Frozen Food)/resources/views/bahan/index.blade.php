@extends('layouts.dashboard')

@section('content')

    <a href="{{ route('bahan.create') }}" class="btn btn-primary">Tambahkan Bahan</a>
    <br><br>

    <table class="table table-bordered table-striped" id="example1">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Nama Bahan</th>
          <th scope="col">Deskripsi</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
        <tbody>
          @foreach ($bahan as $item)
            <tr>
              <th scope="row">{{ $item->id }}</th>
              <td>{{ $item->nama_bahan }}</td>
              <td>{{ $item->deskripsi }}</td>
              <td>
                <a class="btn btn-warning btn-sm" href="/bahan/edit/{{$item->id}}">Edit</a>
                <a class="btn btn-danger btn-sm" href="/bahan/delete/{{$item->id}}" onclick="return confirm('Are You Sure')">Delete</a>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
@endsection