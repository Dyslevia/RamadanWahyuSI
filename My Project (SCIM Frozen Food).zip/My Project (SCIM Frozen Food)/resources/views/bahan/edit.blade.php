@extends('layouts.dashboard')

@section('content')

        <h4>Edit Bahan</h4>
        <form action="/bahan/update/{{$bahan->id}}" method="POST" class="">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nama_bahan" class="form-label">Nama bahan</label>
                <input type="text" class="form-control" id="nama_bahan" name="nama_bahan" placeholder="Masukkan Nama Bahan" value="{{$bahan->nama_bahan}}">
            </div>
            <div class="form-group">
                <label for="deskripsi" class="form-label">Deskripsi</label>
                <input type="text" class="form-control" id="deskripsi" name="deskripsi" placeholder="Masukkan Deskripsi" value="{{$bahan->deskripsi}}">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

@endsection