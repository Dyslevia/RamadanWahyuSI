@extends('layouts.dashboard')
@section('content')

        <form action="/bahan" method="POST" class="">
            @csrf
            <div class="mb-3">
                <label for="nama_bahan" class="form-label">Nama Bahan</label>
                <input type="text" class="form-control" id="nama_bahan" name="nama_bahan" placeholder="Masukan Nama Bahan">
            </div>
            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi</label>
                <input type="text" class="form-control" id="deskripsi" name="deskripsi" placeholder="Masukan Deskripsi">
            </div>
            <button class="btn btn-primary btn-block" type="submit">Simpan</button>
            <a href="{{ route('bahan.index') }}" class="btn btn-secondary btn-block">Batal</a>
        </form>

@endsection