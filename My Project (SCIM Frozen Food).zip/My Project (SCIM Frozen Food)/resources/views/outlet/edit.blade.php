@extends('layouts.dashboard')

@section('content')

        <h4>Edit Outlet</h4>
        <form action="/outlet/update/{{$outlet->id}}" method="POST" class="">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nama_outlet" class="form-label">Nama Outlet</label>
                <input type="text" class="form-control" id="nama_outlet" name="nama_outlet" placeholder="Masukkan Nama Outlet" value="{{$outlet->nama_outlet}}">
            </div>
            <div class="form-group">
                <label for="alamat_outlet" class="form-label">Alamat Outlet</label>
                <input type="text" class="form-control" id="alamat_outlet" name="alamat_outlet" placeholder="Masukkan Alamat Outlet" value="{{$outlet->alamat_outlet}}">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

@endsection