@extends('layouts.dashboard')

@section('content')

        <h4>Edit Stok Barang</h4>
        <form action="/stok-barang/update/{{$stok_barang->id}}" method="POST" class="">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="jumlah_stok" class="form-label">Jumlah stok</label>
                <input type="text" class="form-control" id="jumlah_stok" name="jumlah_stok" placeholder="Masukkan Jumlah Stok" value="{{$stok_barang->jumlah_stok}}">
            </div>
            <br>
            <button class="btn btn-primary" type="submit">Simpan</button>
        </form>

@endsection