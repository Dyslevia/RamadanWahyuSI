@extends('layouts.dashboard')

@section('content')

    <a href="{{ route('stok-barang.create') }}" class="btn btn-primary">Tambahkan Data Stok Barang</a>
    <br><br>
<div class="tabel-responsive">
  <div id="stok-tabel" class="tabel">
    <table class="table table-bordered table-striped" id="example1">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Jumlah Stok</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
        <tbody>
          @foreach ($stok_barang as $item)
            <tr>
              <th scope="row">{{ $item->id }}</th>
              <td>{{ $item->jumlah_stok }}</td>
              <td>
                <a class="btn btn-warning btn-sm" href="/stok-barang/edit/{{$item->id}}">Edit</a>
                <a class="btn btn-danger btn-sm" href="/stok-barang/delete/{{$item->id}}" onclick="return confirm('Are You Sure')">Delete</a>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
  </div>
</div>

@endsection